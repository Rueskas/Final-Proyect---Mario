﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScoreSceneController : MonoBehaviour
{
    public MessageController[] keyboard;
    public MessageController nameMessage;
    public GameObject pointer;
    private ScoreBoard scoreBoard;
    private int pointerPosX;
    private int pointerPosY;
    private string name;
    // Start is called before the first frame update
    void Start()
    {
        pointerPosX = pointerPosY = 0;
        name = "";
        float positionYKeyboard;
        positionYKeyboard = keyboard[0].transform.position.y;

        keyboard[1].transform.position = new Vector2(keyboard[0].transform.position.x,
            positionYKeyboard - 1);
        keyboard[2].transform.position = new Vector2(keyboard[0].transform.position.x,
            positionYKeyboard - 2);

        keyboard[0].SetMessage("a b c d e f g h i j");
        keyboard[1].SetMessage("k l m n o p q r s t");
        keyboard[2].SetMessage("u v w x y z 1 2 3 end");

        for (int i = 0; i < keyboard.Length; i++)
        {
            keyboard[i].Draw();
        }
    }

    // Update is called once per frame
    void Update()
    {
        GetHorizontalInput();
        GetVerticalInput();
        GetModifyInput();
    }

    public void GetHorizontalInput()
    {
        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            pointerPosX--;
            pointer.transform.position = new Vector2(pointer.transform.position.x - 0.9f,
                pointer.transform.position.y);
            if (pointerPosX < 0)
            {
                pointerPosX = 9;
                pointer.transform.position = new Vector2(4.15f,
                    pointer.transform.position.y);
            }
        }
        else if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            pointerPosX++;
            pointer.transform.position = new Vector2(pointer.transform.position.x + 0.9f,
                pointer.transform.position.y);
            if (pointerPosX > 9)
            {
                pointerPosX = 0;
                pointer.transform.position = new Vector2(-3.99f,
                    pointer.transform.position.y);
            }
        }
    }

    public void GetVerticalInput()
    {
        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            pointerPosY--;
            pointer.transform.position = new Vector2(pointer.transform.position.x,
                pointer.transform.position.y + 1);
            if (pointerPosY < 0)
            {
                pointerPosY = 2;
                pointer.transform.position = new Vector2(pointer.transform.position.x,
                    1);
            }
        }
        else if (Input.GetKeyDown(KeyCode.DownArrow))
        {
            pointerPosY++;
            pointer.transform.position = new Vector2(pointer.transform.position.x,
                pointer.transform.position.y - 1);
            if (pointerPosY > 2)
            {
                pointerPosY = 0;
                pointer.transform.position = new Vector2(
                    pointer.transform.position.x, 3);
            }
        }
    }

    public void GetModifyInput()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            WriteName();
        }
        else if (Input.GetKeyDown(KeyCode.Backspace))
        {
            DeleteFromName();
        }
    }

    public void WriteName()
    {
        if(name.Length < 7)
        {
            int posLetter = 0;
            if (pointerPosY != 2 || pointerPosX != 9)
            {
                foreach (char c in keyboard[pointerPosY].GetMessage())
                {
                    if (c != ' ')
                    {
                        if (posLetter == pointerPosX && (pointerPosY != 2 || pointerPosX != 9))
                        {
                            name += c;
                            nameMessage.SetMessage(name);
                            nameMessage.Hide();
                            nameMessage.Draw();
                        }
                        posLetter++;
                    }

                }
            }
        }
    }

    public void DeleteFromName()
    {
        if(name.Length > 0)
        {
            name = name.Substring(0, name.Length - 1);
            nameMessage.SetMessage(name);
            nameMessage.Hide();
            nameMessage.Draw();
        }
    }
}
