﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class GameSceneController : MonoBehaviour
{
    public static int score = 0;
    public static int level = 1;
    public static int enemiesDeath;
    private int enemies;
    private string quantityPlayers;
    private static GameSceneController instance = null;

    void Awake()
    {
        if (instance == null)
            instance = this;
        else if (instance != this)
            Destroy(gameObject);
        
        DontDestroyOnLoad(gameObject);
    }
    // Start is called before the first frame update
    void Start()
    {
        quantityPlayers = "OnePlayer";
        enemies = 0;
        enemiesDeath = -1;
    }

    // Update is called once per frame

    void Update()
    {
        if (enemies == enemiesDeath)
        {
            if (level <= 3 &&
                SceneManager.GetActiveScene().name.StartsWith("Scene"))
            {
                enemiesDeath = -1;
                enemies = 0;
                SceneManager.LoadScene("Demonstration" + level);
            }
            else if (SceneManager.GetActiveScene().name.
                StartsWith("Demonstration"))
            {
                enemies = 2 * level;
                enemiesDeath = 0;
                SceneManager.LoadScene("Scene" + quantityPlayers +
                    "Level" + level);
                level++;
            }
        }
    }

    public static void EnemyKilled(int punctuation)
    {
        score += punctuation;
        enemiesDeath++;
    }

    public void GoToSceneScore()
    {
        SceneManager.LoadScene("SceneScore");
    }

    public void GoBack()
    {
        SceneManager.LoadScene("InitialScene");
        score = 0;
        level = 1;
        quantityPlayers = "OnePlayer";
        enemies = 0;
        enemiesDeath = -1;
    }

    public void SetQuantityPlayers(string quantityPlayers)
    {
        this.quantityPlayers = quantityPlayers;
    }

    public void StartDemonstration1()
    {
        SceneManager.LoadScene("Demonstration1");
    }

    public string GetQuantityPlayers()
    {
        return quantityPlayers;
    }

}
